const { GuildMember } = require("discord.js");

module.exports = {
  name: "guildMemberRemove",
  /**
   * @param {GuildMember} member
   */
  async execute(member) {
    // console.log(member.user.tag);
  },
};
