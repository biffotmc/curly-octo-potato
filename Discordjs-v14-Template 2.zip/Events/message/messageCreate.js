const { Client, Message } = require("discord.js");

module.exports = {
    name: "messageCreate",
    /**
     * @param {Message} message
     * @param {Client} client 
     */
    async execute(client, message) {

    }
}