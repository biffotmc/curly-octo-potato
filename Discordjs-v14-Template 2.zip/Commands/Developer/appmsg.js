const {
    SlashCommandBuilder,
    CommandInteraction,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    PermissionFlagsBits,
    Client
} = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("appmsg")
    
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    /**
     * @param {Client} client
     * @param {CommandInteraction} interaction
     */
    execute(interaction, client) {
        const appembed = new EmbedBuilder()
             .setTitle("Application")
             .setDescription("Press the button below to apply")

        const Row = new ActionRowBuilder()
        Row.addComponents([
          new ButtonBuilder
            .setCustomId("newapplication")
            .setStyle("SUCCESS")
            .setLabel("Apply Here")
        ])
        interaction.reply({ embeds: [appembed], components: [Row] });
    },
};